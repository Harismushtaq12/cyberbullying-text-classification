# Code of Conduct

Be respectful and professional. Harassment, hate speech, and abusive behavior are not tolerated.

This repository works with sensitive text categories; discussion should remain constructive and focused on technical and research goals.
